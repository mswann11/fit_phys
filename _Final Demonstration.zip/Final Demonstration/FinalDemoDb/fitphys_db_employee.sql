-- MySQL dump 10.13  Distrib 8.0.28, for macos11 (x86_64)
--
-- Host: localhost    Database: fitphys_db
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `employee_userTyp` int NOT NULL,
  `employee_fname` varchar(45) NOT NULL,
  `employee_lname` varchar(45) DEFAULT NULL,
  `employee_uname` varchar(45) DEFAULT NULL,
  `employee_password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (0,1,'Admin',NULL,'admin','admin'),(1,2,'Abraham',NULL,'abraham_Bzrp2','P@ssword'),(2,2,'Aeshia',NULL,'aeshia_WK6er','P@ssword'),(3,2,'April',NULL,'april_Tq3Iq','P@ssword'),(4,2,'Art',NULL,'art_ZJcVG','P@ssword'),(5,2,'Becky',NULL,'becky_yZfvH','P@ssword'),(6,2,'Carmen',NULL,'carmen_8Y0GS','P@ssword'),(7,2,'Cole',NULL,'cole_DFIU5','P@ssword'),(8,2,'Dennis',NULL,'dennis_3or2E','P@ssword'),(9,2,'Jade',NULL,'jade_ZQCkG','P@ssword'),(10,2,'June',NULL,'june_LnvTa','P@ssword'),(11,2,'Kennan',NULL,'kennan_XihOy','P@ssword'),(12,2,'Larry',NULL,'larry_yl6Fn','P@ssword'),(13,2,'Latesha',NULL,'latesha_cMJw6','P@ssword'),(14,2,'Mary',NULL,'mary_!TNnl','P@ssword'),(15,2,'Mario',NULL,'mario_pshwQ','P@ssword'),(16,2,'Nathan',NULL,'nathan_UyS2n','P@ssword'),(17,2,'Orlando',NULL,'orlando_BX2M2','P@ssword'),(18,2,'Rick',NULL,'rick_f61ne','P@ssword'),(19,2,'Sarah',NULL,'sarah_KOdHa','P@ssword'),(20,2,'Sasha',NULL,'sasha_92sv6','P@ssword'),(21,2,'Wilbur',NULL,'wilbur_2elh6','P@ssword');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-24 10:02:55
